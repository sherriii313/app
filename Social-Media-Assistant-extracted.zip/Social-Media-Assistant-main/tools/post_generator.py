# tools/post_generator.py

import os
import uuid
from agents import function_tool
from gradio_client import Client

IMAGE_DIR = "generated_posts"
os.makedirs(IMAGE_DIR, exist_ok=True)

@function_tool
def post_generator(topic: str, file_name: str) -> str:
    """
    Generates an image for free using the Stable Diffusion 3 Medium model's public Space.

    Args:
        topic (str): The creative prompt or topic for the image.
        file_name (str): The name for the output file (e.g., "my_post.png").

    Returns:
        str: The full local file path to the generated and saved image.
    """
    print(f"Generating post for topic: '{topic}' with file name: '{file_name}' using Stable Diffusion 3...")

    if '.' not in file_name:
        file_name += ".png"
    local_image_path = os.path.join(IMAGE_DIR, file_name)

    try:
        print("Connecting to Stable Diffusion 3 Space...")
        client = Client("stabilityai/stable-diffusion-3-medium")
        
        # This is the line that was causing the error.
        # The function returns a tuple, so we need to get the first element [0].
        result = client.predict(
            topic,
            "blurry, bad, ugly, text, watermark, signature, low quality",
            api_name="/infer"
        )
        
        # *** THE FINAL FIX IS HERE ***
        # Extract the file path which is the first element of the returned tuple.
        temp_image_path = result[0]
        
        print(f"Temporary image file received at: {temp_image_path}")

        # Copy the image from the temporary path to our final path
        with open(temp_image_path, "rb") as temp_file:
            with open(local_image_path, "wb") as local_file:
                local_file.write(temp_file.read())
        
        print(f"Image saved successfully to: {local_image_path}")
        return local_image_path

    except Exception as e:
        error_message = f"Error during image generation: {e}"
        print(error_message)
        # Give the agent a clear message to relay to the user.
        return f"I am still unable to generate the image. The service might be busy, or there might be an error. Please try again after some time. Technical Error: {e}"