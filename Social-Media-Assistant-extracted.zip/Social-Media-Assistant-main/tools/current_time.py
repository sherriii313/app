from agents import function_tool
from datetime import datetime

@function_tool
def current_time() -> str:
    """
    Returns the current time in a human-readable format.
    
    Returns:
        str: The current time formatted as 'YYYY-MM-DD HH:MM:SS'.
    """
    now = datetime.now()
    return now.strftime("%Y-%m-%d %H:%M:%S")