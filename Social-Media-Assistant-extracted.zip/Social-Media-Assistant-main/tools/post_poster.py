import os
import requests
import datetime
from agents import function_tool
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Get Facebook credentials from environment variables
FACEBOOK_PAGE_ID = os.getenv("FACEBOOK_PAGE_ID") 
FACEBOOK_ACCESS_TOKEN = os.getenv("FACEBOOK_ACCESS_TOKEN")

# Check if credentials are set
if not FACEBOOK_PAGE_ID or not FACEBOOK_ACCESS_TOKEN:
    raise ValueError("FACEBOOK_PAGE_ID and FACEBOOK_ACCESS_TOKEN must be set in the .env file.")

# --- TOOL #1: POST NOW ---
@function_tool
def post_to_facebook(image_path: str, caption: str) -> str:
    """
    Posts an image with a caption to a Facebook Page.

    Args:
        image_path (str): The local file path to the image to be posted.
        caption (str): The text content (caption) for the post.

    Returns:
        str: A success message with the post ID or an error message.
    """
    print(f"--- Calling post_to_facebook ---")
    print(f"Page ID: {FACEBOOK_PAGE_ID}")
    print(f"Image Path: {image_path}")
    print(f"Caption: {caption[:50]}{'...' if len(caption) > 50 else ''}")

    url = f"https://graph.facebook.com/v23.0/{FACEBOOK_PAGE_ID}/photos"
    params = {
        "access_token": FACEBOOK_ACCESS_TOKEN,
        "message": caption
    }
    try:
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Image file not found at {image_path}")
        
        with open(image_path, 'rb') as image_file:
            files = {'source': image_file}
            response = requests.post(url, params=params, files=files)
            response_data = response.json()
            print(f"Response Data: {response_data}")
            response.raise_for_status()
            print(f"Posting to URL: {url} with params: {params}")

        post_id = response_data.get('post_id')
        photo_id = response_data.get('id')
        success_message = f"✅ Successfully posted to Facebook! Photo ID: {photo_id}, Post ID: {post_id}"
        print(success_message)
        return success_message

    except FileNotFoundError as e:
        error_message = f"Error: {str(e)}"
        print(error_message)
        return error_message
    except requests.exceptions.HTTPError as e:
        error_details = e.response.text if e.response else 'No response'
        error_message = f"❌ Error posting to Facebook: {e}. Details: {error_details}"
        print(error_message)
        return error_message
    except Exception as e:
        error_message = f"❌ An unexpected error occurred: {e}"
        print(error_message)
        return error_message

# --- TOOL #2: SCHEDULE POST ---
@function_tool
def schedule_facebook_post(image_path: str, caption: str, schedule_time_str: str) -> str:
    """
    Schedules an image post on a Facebook page for a future time.

    Args:
        image_path (str): The local file path of the image to schedule.
        caption (str): The text content that will accompany the image.
        schedule_time_str (str): The time to schedule the post, in 'YYYY-MM-DD HH:MM' format.

    Returns:
        str: A confirmation message with the post ID if successful, or an error message.
    """
    print(f"--- Calling schedule_facebook_post ---")
    print(f"Image Path: {image_path}")
    print(f"Caption: {caption[:50]}{'...' if len(caption) > 50 else ''}")
    print(f"Schedule Time (local): {schedule_time_str}")

    from datetime import timezone

    # Convert local time to UTC timestamp
    try:
        dt_local = datetime.datetime.strptime(schedule_time_str, "%Y-%m-%d %H:%M")
        dt_utc = dt_local.astimezone(timezone.utc)
        scheduled_publish_time = int(dt_utc.timestamp())
        print(f"Schedule Time (UTC): {dt_utc} -> Timestamp: {scheduled_publish_time}")
    except ValueError:
        error_message = "❌ Error: Invalid time format. Please use 'YYYY-MM-DD HH:MM' format."
        print(error_message)
        return error_message

    # Validate schedule time (between 10 minutes and 75 days from now)
    current_time = datetime.datetime.now(timezone.utc).timestamp()
    if not (current_time + 600 <= scheduled_publish_time <= current_time + 75 * 24 * 60 * 60):
        error_message = "❌ Error: Schedule time must be between 10 minutes and 75 days in the future."
        print(error_message)
        return error_message

    url = f"https://graph.facebook.com/v23.0/{FACEBOOK_PAGE_ID}/photos"
    params = {
        "access_token": FACEBOOK_ACCESS_TOKEN,
        "message": caption,
        "published": False,
        "scheduled_publish_time": scheduled_publish_time
    }

    try:
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Image file not found at {image_path}")

        with open(image_path, 'rb') as image_file:
            files = {'source': image_file}
            response = requests.post(url, params=params, files=files)
            response.raise_for_status()
            response_data = response.json()

        post_id = response_data.get("post_id", "N/A")
        photo_id = response_data.get("id", "N/A")
        confirmation_message = f"✅ Successfully scheduled post for {schedule_time_str} (local time)! Photo ID: {photo_id}, Post ID: {post_id}"
        print(confirmation_message)
        return confirmation_message

    except FileNotFoundError as e:
        error_message = f"❌ Error: {str(e)}"
        print(error_message)
        return error_message
    except requests.exceptions.HTTPError as e:
        error_details = e.response.text if e.response else 'No response'
        error_message = f"❌ Error scheduling post: {e}. Details: {error_details}"
        print(error_message)
        return error_message
    except Exception as e:
        error_message = f"❌ An unexpected error occurred: {e}"
        print(error_message)
        return error_message
