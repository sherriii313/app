from agents import function_tool
import google.generativeai as genai
import os

gemini_api_key = os.getenv("GEMINI_API_KEY")
genai.configure(api_key=gemini_api_key)
model = genai.GenerativeModel('gemini-2.0-flash')

@function_tool
def caption_generator(image_path: str) -> str:
    """
    Generates a caption for the provided image path.

    Args:
        image_path (str): The path to the image for which the caption is to be generated.

    Returns:
        str: A generated caption for the image.
    """
    try:
        # Check if the image exists
        if not os.path.exists(image_path):
            return f"Error: Image not found at {image_path}."

        # Extract a readable file name for caption context
        file_name = os.path.basename(image_path)
        cleaned_name = file_name.replace("_", " ").replace("-", " ").split(".")[0].strip()

        prompt = (
            f"Create a short and engaging social media caption for a Facebook post. "
            f"The image filename is '{cleaned_name}'. Avoid using the filename itself in the caption. "
            f"Make it simple, friendly, and appealing to a general audience."
        )

        response = model.generate_content(prompt)

        if response and hasattr(response, 'text') and response.text:
            return response.text.strip()

        return "Bringing moments to life. ✨"

    except Exception as e:
        print(f"Error generating caption: {e}")
        return "An unexpected error occurred while generating the caption. Please try again later."
