from openai import AsyncOpenAI
from agents import  OpenAIChatCompletionsModel,Agent, Runner
import chainlit as cl
from typing import cast
from tools.post_generator import post_generator
from tools.current_time import current_time
from tools.caption_generator import caption_generator
from tools.post_poster import post_to_facebook, schedule_facebook_post
import os
from dotenv import load_dotenv
import re

gemini_api_key = os.getenv("GEMINI_API_KEY")

if not gemini_api_key:
    raise ValueError("GEMINI_API_KEY environment variable is not set. Please set it to your Gemini API key.")

@cl.on_chat_start
async def start():
    client = AsyncOpenAI(
        api_key=gemini_api_key,
        base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
    )
    model = OpenAIChatCompletionsModel(model="gemini-2.0-flash", openai_client=client)

    agent = Agent(
        name="Social Media Assistant",
        instructions=(
            "You are an intelligent social media assistant. Follow this multi-step process strictly:\n\n"
            "**STEP 1: IMAGE GENERATION**\n"
            "1. User asks to create a post.\n"
            "2. You MUST use the `post_generator` tool. For the 'file_name', create a relevant name.\n"
            "3. Your final output for this step is ONLY the file path.\n\n"
            "**STEP 2: IMAGE APPROVAL**\n"
            "1. The app will show the image to the user.\n"
            "2. **If the user says 'no' or 'change it'**: go back to Step 1 and use `post_generator` again with the improved prompt.\n"
            "3. **If the user says 'yes' or 'it's good'**: your job is DONE for this step. The app will show 'Post Now' and 'Schedule' buttons. Just wait.\n\n"
            "**STEP 3: CAPTION GENERATION**\n"
            "1. Use `caption_generator` with the approved image path.\n"
            "2. Generate a SINGLE good caption based on the image.\n\n"
            "**STEP 4: CAPTION APPROVAL**\n"
            "1. Wait for user approval.\n"
            "2. If approved: ask user to type `post_now` or `schedule_post`.\n"
            "3. If not approved (e.g., 'no', 'na', 'change it'): regenerate a SINGLE new caption.\n\n"
            "**STEP 3: FINAL ACTION (POSTING/SCHEDULING)**\n"
            "1. The user's next message will contain their final choice ('post_now' or 'schedule_post').\n"
            "2. **If the choice is 'post_now'**: Use `post_to_facebook`. CREATE a great caption and use the `image_path` from the prompt.\n"
            "3. **If the choice is 'schedule_post'**: Use `schedule_facebook_post`. CREATE a great caption, use the `image_path`, and also use the `schedule_time_str` from the prompt."
        ),
        model=model,
        tools=[
            post_generator,
            caption_generator,
            post_to_facebook,
            schedule_facebook_post,
            current_time
        ],
    )
    cl.user_session.set("chat_history", [])
    await cl.Message(content="Welcome to the Facebook AI Assistant! How can I help you today?").send()

    cl.user_session.set("agent", agent)


@cl.on_message
async def main(message: cl.Message):
    agent: Agent = cast(Agent, cl.user_session.get("agent"))
    history = cl.user_session.get("chat_history")
    
    # Add context if the user is making a final choice after approving an image
    last_approved_image = cl.user_session.get("last_approved_image")
    if last_approved_image and ("post_now" in message.content or "schedule_post" in message.content):
        message.content = f"The user has made a final choice. Image path is '{last_approved_image}'. User's action and details: '{message.content}'"
        cl.user_session.set("last_approved_image", None) # Clear after use
    
    history.append({"role": "user", "content": message.content})
    
    # Show a "Thinking..." message while the agent is working
    msg = cl.Message(content="Thinking...")
    await msg.send()

    result = await Runner.run(agent, history)
    raw_response = str(result.final_output).strip() # Clean the response
    
    # Find if the agent returned an image path
    match = re.search(r"[\w\s\\/]+\.(?:png|jpg|jpeg|webp)", raw_response, re.IGNORECASE)
    
    if match:
        # Case 1: Image was generated. Show it and ask for approval.
        image_path = match.group(0).replace("\\", "/")
        cl.user_session.set("last_approved_image", image_path) # Save path for next step
        
        elements = [cl.Image(name="Generated Image", display="inline", path=image_path)]
        await cl.Message(
            content="Here is the image I generated. Is this okay, or would you like me to make some changes?",
            elements=elements
        ).send()
        await msg.remove() # Remove the "Thinking..." message
    
    elif "Successfully" in raw_response or "Error" in raw_response:
        # Case 2: Posting/scheduling is complete. Show the final confirmation/error.
        msg.content = raw_response
        await msg.update()
    
    else:
        # Case 3: User approved the image ("yes") or it's a regular conversation.
        # Check if an image is waiting for approval to decide which message to show.
       
            # This is for any other conversational turn
            msg.content = raw_response
            await msg.update()

    cl.user_session.set("chat_history", result.to_input_list())


