# Social-Media-Assistant

**Version**: 0.1.0  
**Description**: An intelligent AI assistant built with OpenAI and Chainlit for generating and posting social media content (images/videos) to LinkedIn, tailored for Madrasa audiences.

This repository contains a social media assistant that automates content creation and posting. To use the assistant effectively, you need to set up the required API tokens and credentials. Below are step-by-step instructions to obtain and configure `FACEBOOK_ACCESS_TOKEN`, `FACEBOOK_PAGE_ID`, and a Hugging Face token, along with how to log in to the Hugging Face Hub using the command line.

## Prerequisites

- Python 3.12 or higher
- Git installed
- A GitHub account
- A Facebook account
- A Hugging Face account

## Setup Instructions

### 1. Obtaining `FACEBOOK_ACCESS_TOKEN` and `FACEBOOK_PAGE_ID`

The assistant requires a Facebook Access Token and Page ID to post content to a Facebook page. Follow these steps:

#### Step 1: Create a Facebook Developer Account
- Go to [Facebook for Developers](https://developers.facebook.com/).
- Click "Get Started" and log in with your Facebook account.
- Follow the prompts to register as a developer by providing your name, email, and accepting the terms.

#### Step 2: Create a Facebook App
- In the Facebook Developer Dashboard, click "My Apps" and select "Create App".
- Choose "Manage Business Integrations" (or another relevant app type) and click "Next".
- Enter a name (e.g., "SocialMediaAssistant") and click "Create App".
- Skip the quickstart setup for now.

#### Step 3: Generate a Facebook Access Token
- Go to [Graph API Explorer](https://developers.facebook.com/tools/explorer/).
- Select your app from the "Application" dropdown.
- Click "Get Token" and select "Get User Access Token".
- In the permissions popup, check the following:
  - `pages_show_list`
  - `pages_read_engagement`
  - `pages_manage_posts`
- Click "Get Access Token" and confirm the request.
- After approval, copy the access token displayed.

#### Step 4: Extend the Access Token (Optional)
- The token expires in 2 months. To extend it:
  - Click the "Info" icon next to the token in Graph API Explorer.
  - Select "Open in Access Token Tool".
  - Click "Extend Access Token" to get a long-lived token (valid for 60 days).
- Copy the extended token.

#### Step 5: Find Your `FACEBOOK_PAGE_ID`
- Go to your Facebook page and look at the URL (e.g., `https://www.facebook.com/YourPageName`).
- The Page ID is the number in the URL or can be found by:
  - Using the Graph API Explorer, query `me/accounts` with your access token.
  - The response will list your pages with their IDs (e.g., `700129496515711`).
- Copy the ID of the page you want to post to.

#### Step 6: Store Credentials
- Create a `.env` file in your project directory (e.g., `D:\Ai Agents\Projects\9.facebook`).
- Add the following lines:
FACEBOOK_ACCESS_TOKEN=your_access_token_here
FACEBOOK_PAGE_ID=your_page_id_here

- Keep this file secure and exclude it from Git using `.gitignore` (see below).

### 2. Obtaining a Hugging Face Token

The project uses Hugging Face for AI models and requires a User Access Token for authentication.

#### Step 1: Sign Up or Log In
- Go to [Hugging Face](https://huggingface.co/).
- Sign up with your email or log in if you already have an account.
- Verify your email if prompted.

#### Step 2: Generate a Hugging Face Token
- Click your profile picture in the top-right corner and select "Settings".
- Navigate to the "Access Tokens" section.
- Click "New token".
- Enter a name (e.g., "SocialMediaAssistantToken").
- Choose the "write" role (to upload models/datasets if needed) or "read" (for read-only access).
- Click "Generate a token".
- Copy the token (e.g., `hf_xxxxxxxxxxxxxxxxxxxxxxxxxx`)—this is the only time it will be visible.

#### Step 3: Store the Token
- Add the token to your `.env` file:
HUGGINGFACE_TOKEN=your_hf_token_here

- Alternatively, set it as an environment variable:
- On Windows: `set HUGGINGFACE_TOKEN=your_hf_token_here` (in Command Prompt).
- On Linux/Mac: `export HUGGINGFACE_TOKEN=your_hf_token_here` (in terminal).

### 3. Logging in to Hugging Face Hub with `huggingface-cli`

To authenticate your machine with the Hugging Face Hub, use the `huggingface-cli` command.

#### Step 1: Install the CLI
- Ensure you have the `huggingface_hub` package installed (included in your `requirements.txt`).
- Verify by running:
```bash
pip show huggingface_hub

```
```
huggingface-cli login
```
```
pip install -r requirements.txt

```



```
chainlit run main.py -w
```